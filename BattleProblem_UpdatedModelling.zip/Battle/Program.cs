﻿using Battle.BusinessLayer;
using Battle.DataAccessLayer;
using Battle.Models;
using System;
using System.Collections.Generic;

namespace Battle
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                String kingInp = Console.ReadLine();
                String oppInp = Console.ReadLine();

                string[] kingInput = kingInp.Split(';');
                string[] oppInput = oppInp.Split(';');

                // Data Object Creation
                PlatoonCreation platoon = new PlatoonCreation();
                List<Soldier> kingPlatton = platoon.CreatePlatoon(kingInput, "King");
                List<Soldier> oppPlatton = platoon.CreatePlatoon(oppInput, "Opponent");

                // Battle
                IAnalyseAdvantage analyse = new AnalyseAdvantageBattleType1();
                analyse.ComputeResult(kingPlatton, oppPlatton);

                Console.ReadKey();
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error while Processing:" + ex.ToString());
                Console.ReadKey();
            }
        }
    }
}


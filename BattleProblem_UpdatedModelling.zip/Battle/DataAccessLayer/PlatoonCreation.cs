﻿using Battle.Models;
using System;
using System.Collections.Generic;

namespace Battle.DataAccessLayer
{
    public class PlatoonCreation
    {
        public List<Soldier> CreatePlatoon(string[] input, string soldierType)
        {
            List<Soldier> soldierPlatoon = new List<Soldier>();

            foreach (var i in input)
            {
                string[] splitInput = i.Split('#');
                String soldierName = splitInput[0];
                int power = int.Parse(splitInput[1]);

                Soldier soldier = new Soldier(soldierName, power, soldierType);
                soldierPlatoon.Add(soldier);
            }
            return soldierPlatoon;
        }
    }
}

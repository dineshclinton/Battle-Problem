﻿using Battle.Models;
using System.Collections.Generic;

namespace Battle.BusinessLayer
{
    interface IAnalyseAdvantage
    {
        // Method to Compute and Print the results
        void ComputeResult(List<Soldier> kingPlatton, List<Soldier> oppPlatton);
    }
}

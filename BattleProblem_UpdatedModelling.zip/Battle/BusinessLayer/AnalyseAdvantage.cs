﻿using Battle.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Battle.Models.CharacterEnum;

namespace Battle.BusinessLayer
{
    // Analyse the Battle Advantage with the provided inputs
    // This Class can be extended later based on the requirements on Properties defined
    public class AnalyseAdvantageBattleType1 : IAnalyseAdvantage
    {
        // Double Advantage metrics
        private static Dictionary<Character, List<Character>> SoldierDoubleAdvantage()
        {
            Dictionary<Character, List<Character>> soldierAdvantage = new Dictionary<Character, List<Character>>();
            soldierAdvantage.Add(Character.Militia, new List<Character> { Character.Spearmen, Character.LightCavalry });
            soldierAdvantage.Add(Character.Spearmen, new List<Character> { Character.LightCavalry, Character.HeavyCavalry });
            soldierAdvantage.Add(Character.LightCavalry, new List<Character> { Character.FootArcher, Character.CavalryArcher });
            soldierAdvantage.Add(Character.HeavyCavalry, new List<Character> { Character.Militia, Character.FootArcher, Character.LightCavalry });
            soldierAdvantage.Add(Character.CavalryArcher, new List<Character> { Character.Spearmen, Character.HeavyCavalry });
            soldierAdvantage.Add(Character.FootArcher, new List<Character> { Character.Militia, Character.CavalryArcher });

            return soldierAdvantage;
        }

        // Data Dictionary generation for Map of the List of Opponent and KingSoldier pairs.
        // Compute the Soldier Characters of Kings army based on the Advantage over individual Opponent Soldier
        private Dictionary<Soldier, List<Soldier>> ComputeSoldierCharacterBasedOnAdvantage(List<Soldier> kSoldiers, List<Soldier> oSoldiers)
        {
            Dictionary<Character, List<Character>> solderAdv = SoldierDoubleAdvantage();
            Dictionary<Soldier, List<Soldier>> dict = new Dictionary<Soldier, List<Soldier>>();

            foreach (var oSoldier in oSoldiers)
            {
                List<Soldier> ksList = new List<Soldier>();
                dict.Add(oSoldier, ksList);
                foreach (var kSoldier in kSoldiers)
                {
                    if ((kSoldier.Power >= oSoldier.Power) || (solderAdv[kSoldier.SoldierName].Contains(oSoldier.SoldierName) && 2 * kSoldier.Power >= oSoldier.Power))
                    {
                        ksList.Add(kSoldier);
                    }
                }
            }

            return dict;
        }

        private void AnalyseAndPrintResult(List<Soldier> kingPlatton, List<Soldier> oppPlatton, Dictionary<Soldier, List<Soldier>> dict)
        {
            Dictionary<Soldier, Soldier> resultDict = new Dictionary<Soldier, Soldier>();
            SortedDictionary<int, List<Soldier>> sDictOpp = new SortedDictionary<int, List<Soldier>>();
            List<Soldier> listOppSoldiers = new List<Soldier>();

            //Creating the Sorted Dictionary based on the count of the Opponent Soldiers
            foreach (var item in dict)
            {
                if (item.Value.Count > 0)
                {
                    listOppSoldiers.Add(item.Key);
                    if (!sDictOpp.ContainsKey(item.Value.Count))
                    {
                        sDictOpp.Add(item.Value.Count, listOppSoldiers);
                    }
                }
            }

            List<Soldier> kTemp = new List<Soldier>();

            //Iterate the sorted dictionary to pick the first element of the kingSoldier (in case multiple items on same sort order exists)
            foreach (var item in sDictOpp)
            {
                IterateThroughKings(dict, resultDict, kTemp, item);
            }

            if (resultDict.Count < 3)
            {
                Console.WriteLine("There is no chance of winning");
            }
            else
            {
                // Print all the result Dictinary is the order of the opponent Platton
                // If the resultDictionary doesnt contains the value, pick the value to be
                // populated from the temp solder list and original list, which is not present in the temp list
                // add the result to temp list for reduntant comptation
                StringBuilder sb = new StringBuilder();
                foreach (var item in oppPlatton)
                {
                    if (!resultDict.ContainsKey(item))
                    {
                        var ks = kingPlatton.Intersect(kTemp).First();
                        resultDict.Add(item, ks);
                        kTemp.Add(ks);
                    }
                    sb.Append(resultDict[item].SoldierName + "#" + resultDict[item].Power + ";");
                }

                Console.WriteLine(sb.ToString().TrimEnd(';'));
            }
        }

        //Iterate through individual kings and output the result to resutlDict
        private void IterateThroughKings(Dictionary<Soldier, List<Soldier>> dict, Dictionary<Soldier, Soldier> resultDict, List<Soldier> kTemp, KeyValuePair<int, List<Soldier>> item)
        {
            foreach (var sDictOpp_val in item.Value)
            {
                foreach (var kingSold in dict[sDictOpp_val])
                {
                    if (!kTemp.Contains(kingSold))
                    {
                        kTemp.Add(kingSold);
                        resultDict[sDictOpp_val] = kingSold;
                        break;
                    }
                }
            }
        }

        // Method to Compute and Print the results
        public void ComputeResult(List<Soldier> kingPlatton, List<Soldier> oppPlatton)
        {
            Dictionary<Soldier, List<Soldier>> dict = ComputeSoldierCharacterBasedOnAdvantage(kingPlatton, oppPlatton);
            AnalyseAndPrintResult(kingPlatton, oppPlatton, dict);
        }
    }
}

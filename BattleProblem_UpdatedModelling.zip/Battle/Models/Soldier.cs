﻿using System;
using static Battle.Models.CharacterEnum;

namespace Battle.Models
{
    // Soldier Base Class
    public class Soldier : ISoldier
    {
        // Property - Power - defines the count
        public int Power { get; private set; }
        
        // Propery - Characted - defines the soldier
        public Character SoldierName { get; private set; }

        // Contructor for getting the inputs
        public Soldier(String soldier, int power, string type)
        {
            Power = power;
            SoldierName = MapSoldier(soldier);
            SoldierType = type;
        }

        // Map the soldier name with the respective enum members
        public Character MapSoldier(string character)
        {
            switch (character)
            {
                case "Militia":
                    return Character.Militia;
                case "Spearmen":
                    return Character.Spearmen;
                case "LightCavalry":
                    return Character.LightCavalry;
                case "HeavyCavalry":
                    return Character.HeavyCavalry;
                case "CavalryArcher":
                    return Character.CavalryArcher;
                case "FootArcher":
                default:
                    return Character.FootArcher;
            }
        }

        public string SoldierType { get; set; }
    }
}

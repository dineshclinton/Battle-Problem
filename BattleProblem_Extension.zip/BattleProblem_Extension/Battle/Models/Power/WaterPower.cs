﻿using static Battle.Models.CharacterEnum;

namespace Battle.Models
{
    // Water Power is a sub type of the Power
    // The power by default is generated as 1000
    public class WaterPower : IPower
    {
        public int GetPower()
        {
            return 1000;
        }
    }
}

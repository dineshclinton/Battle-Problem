﻿using static Battle.Models.CharacterEnum;

namespace Battle.Models
{
    // Contract for Power
    // Different types of Powers can be possessed
    // Like WaterPower, LandPower
    public interface IPower
    {
        int GetPower();
    }
}

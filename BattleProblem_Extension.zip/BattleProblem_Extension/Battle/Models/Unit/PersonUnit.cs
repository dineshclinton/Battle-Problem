﻿namespace Battle.Models
{
    // Person Unit is a Derived entity of Unit
    public class PersonUnit : Unit
    {
        // New Power is based on the power attribute updated
        // In future many  Unit specific functionalities can be updated
        public override int ChangePower(IPower power)
        {
            NewPower = power.GetPower();
            return NewPower;
        }
    }
}

﻿namespace Battle.Models
{
    // Animal Unit is a derived entity of Unit
    public class AnimalUnit : Unit
    {
        // The power is in defaule is reduced by 100
        // Then the power is multiplied by the power
        // that are assigned to
        public override int ChangePower(IPower power)
        {
            var reducedPower = OriginalPower - 100;
            NewPower = power.GetPower() * reducedPower;
            return NewPower;
        }
    }
}

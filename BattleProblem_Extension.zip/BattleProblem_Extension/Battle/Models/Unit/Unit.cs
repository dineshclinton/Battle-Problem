﻿namespace Battle.Models
{
    // Base class for for Unit
    // Extended for all different Units in Future
    // Like PersonUnit, AnimalUnit, DroneUnit, RobotUnit
    // In future many  Unit specific functionalities can be updated
    public abstract class Unit
    {
        public string UnitName { get; set; }

        public int OriginalPower { get; set; }

        // Default Power -> Original Power is assiged to NewPower
        public void DefaultPower()
        {
            NewPower = OriginalPower;
        }

        public int NewPower { get; set; }

        // Extensible method to override the compute and change power based on requirement
        public abstract int ChangePower(IPower power);
    }
}

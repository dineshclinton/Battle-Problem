﻿namespace Battle.Models
{
    public class CharacterEnum
    {
        public enum Character
        {
            Militia,
            Spearmen,
            LightCavalry,
            HeavyCavalry,
            CavalryArcher,
            FootArcher
        }
    }
}

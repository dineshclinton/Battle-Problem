﻿using Battle.Models;
using System.Collections.Generic;

namespace Battle.BusinessLayer
{
    // Analyse the Battle Advantage with the provided inputs
    // The winning criterial is the total soldiers greater that the loosing soldier
    // All draws are considered as no chance of winning
    // total soldiers are 10,
    // Wins = 6 => 10/2 => 5 < 6 => Hence win
    // Wins = 5 => 10/2 = 5 = 5 => Hence no chance of winning
    public class AnalyseAdvantageBattleType2 : AnalyseAdvantageBattleType1
    {
        public AnalyseAdvantageBattleType2(List<Soldier> oppPlatton) : base(oppPlatton)
        {

        }

        // Can Win Criteria is overriden.
        public override bool CanWin(int resultDictCount, int soldCount)
        {

            if (resultDictCount > soldCount / 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

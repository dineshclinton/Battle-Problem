﻿using Battle.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Battle.Models.CharacterEnum;

namespace Battle.BusinessLayer
{
    // Analyse the Battle Advantage with the provided inputs
    // This Class can be extended later based on the requirements on Properties defined
    public class AnalyseAdvantageBattleType1 : IAnalyseAdvantage
    {
        public Dictionary<Soldier, Soldier> resultDictCompute { get; set; }
        public bool resultFound { get; set; }
        public bool stopRecursion { get; set; }

        public AnalyseAdvantageBattleType1(List<Soldier> oppPlatton)
        {
            resultDictCompute = new Dictionary<Soldier, Soldier>();
            foreach (var item in oppPlatton)
            {
                resultDictCompute.Add(item, null);
            }
        }
        // Double Advantage metrics
        private static Dictionary<Character, List<Character>> SoldierDoubleAdvantage()
        {
            Dictionary<Character, List<Character>> soldierdoubleAdvantage = new Dictionary<Character, List<Character>>();
            soldierdoubleAdvantage.Add(Character.Militia, new List<Character> { Character.Spearmen, Character.LightCavalry });
            soldierdoubleAdvantage.Add(Character.Spearmen, new List<Character> { Character.LightCavalry, Character.HeavyCavalry });
            soldierdoubleAdvantage.Add(Character.LightCavalry, new List<Character> { Character.FootArcher, Character.CavalryArcher });
            soldierdoubleAdvantage.Add(Character.HeavyCavalry, new List<Character> { Character.Militia, Character.FootArcher, Character.LightCavalry });
            soldierdoubleAdvantage.Add(Character.CavalryArcher, new List<Character> { Character.Spearmen, Character.HeavyCavalry });
            soldierdoubleAdvantage.Add(Character.FootArcher, new List<Character> { Character.Militia, Character.CavalryArcher });

            return soldierdoubleAdvantage;
        }

        // Data Dictionary generation for Map of the List of Opponent and KingSoldier pairs.
        // Compute the Soldier Characters of Kings army based on the Advantage over individual Opponent Soldier
        private Dictionary<Soldier, List<Soldier>> ComputeSoldierCharacterBasedOnWinAdvantage(List<Soldier> kSoldiers, List<Soldier> oSoldiers)
        {
            Dictionary<Character, List<Character>> solderdoubleAdv = SoldierDoubleAdvantage();
            Dictionary<Soldier, List<Soldier>> dict = new Dictionary<Soldier, List<Soldier>>();

            foreach (var oSoldier in oSoldiers)
            {
                List<Soldier> ksList = new List<Soldier>();
                dict.Add(oSoldier, ksList);
                foreach (var kSoldier in kSoldiers)
                {
                    if ((kSoldier.Power > oSoldier.Power) || (solderdoubleAdv[kSoldier.SoldierName].Contains(oSoldier.SoldierName) && 2 * kSoldier.Power > oSoldier.Power))
                    {
                        ksList.Add(kSoldier);
                    }
                }
            }

            return dict;
        }

        // Data Dictionary generation for Map of the List of Opponent and KingSoldier pairs.
        // Compute the Soldier Characters of Kings army based on the Advantage over individual Opponent Soldier
        public Dictionary<Soldier, List<Soldier>> ComputeSoldierCharacterBasedOnDrawAdvantage(List<Soldier> kSoldiers, List<Soldier> oSoldiers)
        {
            Dictionary<Character, List<Character>> solderAdv = SoldierDoubleAdvantage();
            Dictionary<Soldier, List<Soldier>> dict = new Dictionary<Soldier, List<Soldier>>();

            foreach (var oSoldier in oSoldiers)
            {
                List<Soldier> ksList = new List<Soldier>();
                dict.Add(oSoldier, ksList);
                foreach (var kSoldier in kSoldiers)
                {
                    if ((kSoldier.Power == oSoldier.Power) || (solderAdv[kSoldier.SoldierName].Contains(oSoldier.SoldierName) && 2 * kSoldier.Power == oSoldier.Power))
                    {
                        ksList.Add(kSoldier);
                    }
                }
            }

            return dict;
        }

        private void AnalyseAndPrintResult(List<Soldier> kingPlatton, List<Soldier> oppPlatton, Dictionary<Soldier, List<Soldier>> dict)
        {
            Dictionary<Soldier, Soldier> resultDict = new Dictionary<Soldier, Soldier>();
            SortedDictionary<int, List<Soldier>> sDictOpp = new SortedDictionary<int, List<Soldier>>();
            List<Soldier> listOppSoldiers = new List<Soldier>();

            CreateSortedDictionary(dict, sDictOpp, listOppSoldiers);

            List<Soldier> kTemp = AnalyseWin(dict, resultDict, sDictOpp);

            ComputeWinningCriteria(kingPlatton, oppPlatton, resultDict, kTemp);
        }

        public virtual void ComputeWinningCriteria(List<Soldier> kingPlatton, List<Soldier> oppPlatton, Dictionary<Soldier, Soldier> resultDict, List<Soldier> kTemp)
        {
            if (!stopRecursion)
            {
                var canWin = CanWin(resultDict.Count, kingPlatton.Count);
                // total soldiers are 10,
                // Wins = 6 => 10/2 => 5 < 6 => Hence win
                // Wins = 5 => 10/2 = 5 = 5 => Hence no chance of winning
                if (!canWin && !resultFound)
                {
                    Dictionary<Soldier, List<Soldier>> dict = ComputeSoldierCharacterBasedOnDrawAdvantage(kingPlatton, oppPlatton);

                    var tempKingPlatton = kingPlatton;
                    var tempOppPlatton = oppPlatton;

                    foreach (var item in dict)
                    {
                        foreach (var x in item.Value)
                        {
                            tempOppPlatton.Remove(item.Key);
                            tempKingPlatton.Remove(x);
                            resultDictCompute[item.Key] = x;
                            this.ComputeResult(tempKingPlatton, tempOppPlatton);
                        }
                    }
                }
                else
                {
                    resultFound = true;
                    ComputeWinResultDict(kingPlatton, oppPlatton, resultDict, kTemp);
                    PrintWin(resultDictCompute);
                    stopRecursion = true;
                    //PrintWin(kingPlatton, oppPlatton, resultDict, kTemp);
                }

                if (!resultFound && !stopRecursion)
                {
                    stopRecursion = true;
                    Console.WriteLine("There is no chance of winning");
                }
            }
        }

        public virtual bool CanWin(int resultDictCount, int soldCount)
        {

            if (resultDictCount > soldCount / 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private List<Soldier> AnalyseWin(Dictionary<Soldier, List<Soldier>> dict, Dictionary<Soldier, Soldier> resultDict, SortedDictionary<int, List<Soldier>> sDictOpp)
        {
            List<Soldier> kTemp = new List<Soldier>();

            //Iterate the sorted dictionary to pick the first element of the kingSoldier (in case multiple items on same sort order exists)
            foreach (var item in sDictOpp)
            {
                IterateThroughKings(dict, resultDict, kTemp, item);
            }

            return kTemp;
        }

        private static void CreateSortedDictionary(Dictionary<Soldier, List<Soldier>> dict, SortedDictionary<int, List<Soldier>> sDictOpp, List<Soldier> listOppSoldiers)
        {
            //Creating the Sorted Dictionary based on the count of the Opponent Soldiers
            foreach (var item in dict)
            {
                if (item.Value.Count > 0)
                {
                    listOppSoldiers.Add(item.Key);
                    if (!sDictOpp.ContainsKey(item.Value.Count))
                    {
                        sDictOpp.Add(item.Value.Count, new List<Soldier>() { item.Key });
                    }
                    else
                    {
                        if (!sDictOpp[item.Value.Count].Contains(item.Key))
                            sDictOpp[item.Value.Count].Add(item.Key);
                    }
                }
            }
        }

        public static void PrintWin(Dictionary <Soldier,Soldier> resultWinDict)
        {
            // Print all the result Dictionary in the order of the opponent Platton
            StringBuilder sb = new StringBuilder();
            foreach (var item in resultWinDict)
            {
                sb.Append(resultWinDict[item.Key].SoldierName + "#" + resultWinDict[item.Key].Power + ";");
            }

            Console.WriteLine(sb.ToString().TrimEnd(';'));
        }

        public void ComputeWinResultDict(List<Soldier> kingPlatton, List<Soldier> oppPlatton, Dictionary<Soldier, Soldier> resultWinDict, List<Soldier> kTemp)
        {

            // Get all the result Dictinary is the order of the opponent Platton
            // If the resultDictionary doesnt contains the value, pick the value to be
            // populated from the temp solder list and original list, which is not present in the temp list
            // add the result to temp list for reduntant comptation
            foreach (var item in oppPlatton)
            {
                if (resultWinDict.ContainsKey(item))
                {
                    resultDictCompute[item] = resultWinDict[item];
                }
                else
                {
                    foreach (var x in kingPlatton)
                    {
                        if (!kTemp.Contains(x))
                        {
                            kTemp.Add(x);
                            resultDictCompute[item] = x;
                            break;
                        }
                    }
                }
            }
        }

        // sorted dictionary will have key => count,  value = > list of opponents
        //Iterate through individual kings and output the result to resutlDict
        private void IterateThroughKings(Dictionary<Soldier, List<Soldier>> dict, Dictionary<Soldier, Soldier> resultDict, List<Soldier> kTemp, KeyValuePair<int, List<Soldier>> item)
        {
            // from one by one oppenent
            foreach (var sDictOpp_val in item.Value)
            {
                // get the kings who can win over that opponent
                foreach (var kingSold in dict[sDictOpp_val])
                {
                    if (!kTemp.Contains(kingSold))
                    {
                        kTemp.Add(kingSold);
                        resultDict[sDictOpp_val] = kingSold;
                        break;
                    }
                }
            }
        }

        // Method to Compute and Print the results
        public void ComputeResult(List<Soldier> kingPlatton, List<Soldier> oppPlatton)
        {
            Dictionary<Soldier, List<Soldier>> dict = ComputeSoldierCharacterBasedOnWinAdvantage(kingPlatton, oppPlatton);
            AnalyseAndPrintResult(kingPlatton, oppPlatton, dict);
        }
    }
}

﻿using Battle.Models;
using System;
using System.Collections.Generic;

namespace Battle.DataAccessLayer
{
    public class PlatoonCreation
    {
        // Creating a platoon
        public List<Soldier> CreatePlatoon(string[] input, string soldierType)
        {
            List<Soldier> soldierPlatoon = new List<Soldier>();

            foreach (var i in input)
            {
                string[] splitInput = i.Split('#');
                String soldierName = splitInput[0];
                int power = int.Parse(splitInput[1]);

                // Calling the soldier creation service
                SoldierCreationService soldierCreate = new SoldierCreationService();
                var soldier = soldierCreate.CreateSoldier(soldierName, power, soldierType);

                //Soldier soldier = new Soldier(soldierName, power, soldierType);
                soldierPlatoon.Add(soldier);
            }
            return soldierPlatoon;
        }
    }
}

﻿using Battle.Models;

namespace Battle.DataAccessLayer
{
    public class SoldierCreationService
    {
        /* Service Layer to Create the objects and injects into the Business logic as required
             - This can be extended to read the inputs from other sources like DB or config files and process based on
             - The objects on the Unit with Power is created and then assigned to Soldier
             - Based on the sodier types, the powers can be altered
        */
        public Soldier CreateSoldier(string soldierName, int power, string soldierType)
        {
            Soldier soldier = new Soldier(soldierName, power, soldierType);
            // switch case (or) based on the inputs read
            PersonUnit personUnit = new PersonUnit();
            personUnit.OriginalPower = power;
            personUnit.DefaultPower();
            soldier.AddUnit(personUnit);

            //if (soldierName == "HeavyCavalry")
            //{
            //    AnimalUnit animalUnit = new AnimalUnit();
            //    animalUnit.OriginalPower = power;
            //    animalUnit.ChangePower(new WaterPower());
            //    soldier.AddUnit(animalUnit);
            //}

            //AnimalUnit animalUnit = new AnimalUnit();
            //animalUnit.OriginalPower = power;
            //animalUnit.ChangePower(new WaterPower());
            //soldier.AddUnit(animalUnit);

            //personUnit = new PersonUnit();
            //personUnit.OriginalPower = power;
            //personUnit.ChangePower(new WaterPower());
            //soldier.AddUnit(personUnit);


            return soldier;
        }
    }
}

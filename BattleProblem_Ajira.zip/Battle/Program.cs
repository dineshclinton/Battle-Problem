﻿using Battle.BusinessLayer;
using Battle.DataAccessLayer;
using Battle.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battle
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                String kingInp = Console.ReadLine();
                String oppInp = Console.ReadLine();

                string[] kingInput = kingInp.Split(';');
                string[] oppInput = oppInp.Split(';');

                // Data Object Creation
                PlatoonCreation platoon = new PlatoonCreation();
                List<KingSoldier> kingPlatton = platoon.CreateKingPlatoon(kingInput);
                List<OpponentSoldier> oppPlatton = platoon.CreateOpponentPlatoon(oppInput);

                // Data Dictionary generation for Map of the List of Opponent and KingSoldier pairs.
                AnalyseAdvantage analyse = new AnalyseAdvantage();
                var dict = analyse.ComputeSoldierCharacterBasedOnAdvantage(oppPlatton, kingPlatton);

                // Result Processing
                ComputeResult(kingPlatton, oppPlatton, dict);

                Console.ReadKey();
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error while Processing:" + ex.ToString());
                Console.ReadKey();
            }
        }

        // Method to Compute and Print the results
        private static void ComputeResult(List<KingSoldier> kingPlatton, List<OpponentSoldier> oppPlatton, Dictionary<OpponentSoldier, List<KingSoldier>> dict)
        {
            Dictionary<OpponentSoldier, KingSoldier> resultDict = new Dictionary<OpponentSoldier, KingSoldier>();
            SortedDictionary<int, List<OpponentSoldier>> sDict = new SortedDictionary<int, List<OpponentSoldier>>();
            List<OpponentSoldier> listOppSoldiers = new List<OpponentSoldier>();

            //Creating the Sorted Dictionary based on the count of the Opponent Soldiers
            foreach (var item in dict)
            {
                if (item.Value.Count > 0)
                {
                    listOppSoldiers.Add(item.Key);
                    if (!sDict.ContainsKey(item.Value.Count))
                    {
                        sDict.Add(item.Value.Count, listOppSoldiers);
                    }
                }
            }

            List<KingSoldier> kTemp = new List<KingSoldier>();

            //Iterate the sorted dictionary to pick the first element of the kingSoldier (in case multiple items on same sort order exists)
            foreach (var item in sDict)
            {
                foreach (var sDictOpp in item.Value)
                {
                    foreach (var kingSold in dict[sDictOpp])
                    {
                        if (!kTemp.Contains(kingSold))
                        {
                            kTemp.Add(kingSold);
                            resultDict[sDictOpp] = kingSold;
                            break;
                        }
                    }
                }
            }

            if (resultDict.Count < 3)
            {
                Console.WriteLine("There is no chance of winning");
            }
            else
            {
                // Print all the result Dictinary is the order of the opponent Platton
                // If the resultDictionary doesnt contains the value, pick the value to be
                // populated from the temp solder list and original list, which is not present in the temp list
                // add the result to temp list for reduntant comptation
                StringBuilder sb = new StringBuilder();
                foreach (var item in oppPlatton)
                {
                    if (!resultDict.ContainsKey(item))
                    {
                        var ks = kingPlatton.Intersect(kTemp).First();
                        resultDict.Add(item, ks);
                        kTemp.Add(ks);
                    }
                    sb.Append(resultDict[item].SoldierName + "#" + resultDict[item].Power + ";");
                }

                Console.WriteLine(sb.ToString().TrimEnd(';'));
            }
        }
    }
}


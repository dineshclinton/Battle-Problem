﻿using Battle.Models;
using System.Collections.Generic;
using static Battle.Models.CharacterEnum;

namespace Battle.BusinessLayer
{
    // Analyse the Battle Advantage with the provided inputs
    // This Class can be extended later based on the requirements on Properties defined
    public class AnalyseAdvantage
    {
        // Double Advantage metrics
        private static Dictionary<Character, List<Character>> SoldierDoubleAdvantage()
        {
            Dictionary<Character, List<Character>> soldierAdvantage = new Dictionary<Character, List<Character>>();
            soldierAdvantage.Add(Character.Militia, new List<Character> { Character.Spearmen, Character.LightCavalry });
            soldierAdvantage.Add(Character.Spearmen, new List<Character> { Character.LightCavalry, Character.HeavyCavalry });
            soldierAdvantage.Add(Character.LightCavalry, new List<Character> { Character.FootArcher, Character.CavalryArcher });
            soldierAdvantage.Add(Character.HeavyCavalry, new List<Character> { Character.Militia, Character.FootArcher, Character.LightCavalry });
            soldierAdvantage.Add(Character.CavalryArcher, new List<Character> { Character.Spearmen, Character.HeavyCavalry });
            soldierAdvantage.Add(Character.FootArcher, new List<Character> { Character.Militia, Character.CavalryArcher });

            return soldierAdvantage;
        }

        // Compute the Soldier Characters of Kings army based on the Advantage over individual Opponent Soldier
        public Dictionary<OpponentSoldier, List<KingSoldier>> ComputeSoldierCharacterBasedOnAdvantage(List<OpponentSoldier> oSoldiers, List<KingSoldier> kSoldiers)
        {
            Dictionary<Character, List<Character>> solderAdv = SoldierDoubleAdvantage();
            Dictionary<OpponentSoldier, List<KingSoldier>> dict = new Dictionary<OpponentSoldier, List<KingSoldier>>();

            foreach (var oSoldier in oSoldiers)
            {
                List<KingSoldier> ksList = new List<KingSoldier>();
                dict.Add(oSoldier, ksList);
                foreach (var kSoldier in kSoldiers)
                {
                    if ((kSoldier.Power >= oSoldier.Power) || (solderAdv[kSoldier.SoldierName].Contains(oSoldier.SoldierName) && 2 * kSoldier.Power >= oSoldier.Power))
                    {
                        ksList.Add(kSoldier);
                    }
                }
            }

            return dict;
        }
    }
}

﻿using Battle.Models;
using System;
using System.Collections.Generic;

namespace Battle.DataAccessLayer
{
    public class PlatoonCreation
    {
        public List<KingSoldier> CreateKingPlatoon(string[] input)
        {
            List<KingSoldier> kingSoldierPlatoon = new List<KingSoldier>();

            foreach (var i in input)
            {
                string[] splitInput = i.Split('#');
                String soldierName = splitInput[0];
                int power = int.Parse(splitInput[1]);

                KingSoldier soldier = new KingSoldier(soldierName, power);
                kingSoldierPlatoon.Add(soldier);
            }
            return kingSoldierPlatoon;
        }

        public List<OpponentSoldier> CreateOpponentPlatoon(string[] input)
        {
            List<OpponentSoldier> oppSoldierPlatoon = new List<OpponentSoldier>();

            foreach (var i in input)
            {
                string[] splitInput = i.Split('#');
                String soldierName = splitInput[0];
                int power = int.Parse(splitInput[1]);

                OpponentSoldier soldier = new OpponentSoldier(soldierName, power);
                oppSoldierPlatoon.Add(soldier);
            }
            return oppSoldierPlatoon;
        }
    }
}

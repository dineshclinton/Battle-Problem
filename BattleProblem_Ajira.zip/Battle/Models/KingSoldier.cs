﻿namespace Battle.Models
{
    // King's Soldier
    public class KingSoldier : Soldier
    {
        public KingSoldier(string soldier, int power) : base(soldier, power)
        {
        }
    }
}

﻿using System;
using static Battle.Models.CharacterEnum;

namespace Battle.Models
{
    // Soldier Base Class
    public class Soldier : ISoldier
    {
        // Property - Power - defines the count
        public int Power { get; set; }
        
        // Propery - Characted - defines the soldier
        public Character SoldierName { get; set; }

        // Contructor for getting the inputs
        public Soldier(String soldier, int power)
        {
            Power = power;
            SoldierName = GetSoldierName(soldier);
        }

        // Map the soldier name with the respective enum members
        public Character GetSoldierName(string character)
        {
            switch (character)
            {
                case "Militia":
                    return Character.Militia;
                case "Spearmen":
                    return Character.Spearmen;
                case "LightCavalry":
                    return Character.LightCavalry;
                case "HeavyCavalry":
                    return Character.HeavyCavalry;
                case "CavalryArcher":
                    return Character.CavalryArcher;
                case "FootArcher":
                default:
                    return Character.FootArcher;
            }
        }
    }
}

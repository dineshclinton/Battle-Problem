﻿namespace Battle.Models
{
    // Opponet's Soldier
    public class OpponentSoldier : Soldier
    {
        public OpponentSoldier(string soldier, int power) : base(soldier, power)
        {
        }
    }
}

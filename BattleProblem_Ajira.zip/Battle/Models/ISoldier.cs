﻿using static Battle.Models.CharacterEnum;

namespace Battle.Models
{
    // Contract for folder Soldier
    public interface ISoldier
    {
        Character GetSoldierName(string character);
    }
}
